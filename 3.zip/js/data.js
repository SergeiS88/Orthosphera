const dataB =
[
    {
    "id": "1",
    "name": "Бесы",
    "author": "Достоевский Ф.М.",
    "description": "Всегда современный политический роман о пагубных идеях и их оседлавших",
    "img": "./img/books/besi.jpg",
    },
    {
    "id": "2",
    "name": "Тихий Дон",
    "author": "Шолохов М.С.",
    "description": "Русская социалистическая революция и просто жизнь в реалистическом исполнении.",
    "img": "./img/books/tihijdon.jpg",
    },
    {
    "id": "3",
    "name": "Война и Мир",
    "author": "Толстой Л.Н.",
    "description": "Быт и война русского света и русского народа",
    "img": "./img/books/voinaimir.jpg",
    },
];
const bestBooks = JSON.stringify(dataB);


const dataM = [
    {
    'id': "1",
    'treck': './music/CHajjkovskijj.mp3', 
    'artist': 'Чайсковский П.И.',
    'label': 'Русский танец',
    }, 
    {
    'id': "2",
    'treck': './music/Jamshik.mp3',
    'artist': 'Погудин О.Е.',
    'label': 'Ямщик не гони лошадей',
    },
    {
    'id': "3",
    'treck': './music/not_for_me.mp3', 
    'artist': 'Кубанский Казачий Хор',
    'label': 'Не для меня',
    },
    {
    'id': "4",
    'treck': './music/orthodox.mp3',
    'artist': 'Хор Александра Свирского Монастыря',
    'label': 'Достойно есть',
    },
    {
    'id': "5",
    'treck': './music/fire.mp3',
    'artist': 'Марк Бернес',
    'label': 'Вьётся в тесной печурке огонь',
    },
    {
    'id': "6",
    'treck': './music/tired_sun.mp3',
    'artist': 'Ежи Петерсбурский',
    'label': 'Утомлённое солнце',
    },
];
const bestMusic = JSON.stringify(dataM);
