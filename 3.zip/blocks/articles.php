<section class="articles center">
    <h2>header2</h2>
    <article>
        <img src="./img/avat.jpg" alt="статья {{ articlesId }}">
        <h3>header3</h3>
        <p>description</p>
        <a href="#">link</a>
    </article>    
</section>