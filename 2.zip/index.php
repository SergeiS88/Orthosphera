<?php
    define('ROOT__DIR', __FILE__);

    require "blocks/layout.php";
?>